import pandas as pd
import numpy as np
from sklearn.preprocessing import RobustScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.metrics import f1_score
import warnings
import os

#Kiana Khalili S358153 Fall 2026 DSL Project

warnings.filterwarnings('ignore')


class PatientSurvivalPredictor:
    
    def __init__(self, random_state=42):
        self.random_state = random_state
        self.feature_scaler = None
        self.feature_selector = None
        self.ensemble_model = None
        self.optimal_threshold = 0.5
        self.selected_feature_names = None
        self.training_columns = None
        
    def load_datasets(self, dev_path, eval_path):
        development_data = pd.read_csv(dev_path)
        evaluation_data = pd.read_csv(eval_path)
        
        print(f"Development set: {development_data.shape[0]} patients, {development_data.shape[1]} features")
        print(f"Evaluation set: {evaluation_data.shape[0]} patients, {evaluation_data.shape[1]} features")
        
        return development_data, evaluation_data
    
    def prepare_features(self, patient_records):
        feature_frame = patient_records.copy()
        
        feature_frame['age'] = feature_frame['age'].fillna(feature_frame['age'].median())
        age_bucket = pd.cut(feature_frame['age'], bins=[-1, 40, 60, 200], labels=[1, 2, 3])
        feature_frame['age_group'] = age_bucket.astype(float).fillna(2).astype(int)
        
        severity_score = (
            feature_frame['num.co'].fillna(0) * 0.3 +
            feature_frame['aps'].fillna(0) * 0.4 +
            feature_frame['sps'].fillna(0) * 0.3
        )
        feature_frame['severity_index'] = severity_score
        
        abnormal_labs = (
            (feature_frame['bili'] > 1.2).astype(int) +
            (feature_frame['crea'] > 1.2).astype(int) +
            (feature_frame['bun'] > 20).astype(int) +
            (feature_frame['glucose'] > 200).astype(int)
        )
        feature_frame['lab_abnormality_count'] = abnormal_labs
        
        feature_frame['oxygen_efficiency'] = feature_frame['pafi'] / (feature_frame['meanbp'] + 1)
        feature_frame['metabolic_stress'] = feature_frame['glucose'] * feature_frame['temp'] / 100
        
        numeric_columns = feature_frame.select_dtypes(include=[np.number]).columns
        feature_frame[numeric_columns] = feature_frame[numeric_columns].fillna(feature_frame[numeric_columns].median())
        
        return feature_frame
    
    def remove_outliers(self, patient_data, target_column=None, vote_threshold=8):
        numeric_cols = patient_data.select_dtypes(include=[np.number]).columns
        outlier_votes = pd.Series(0, index=patient_data.index)
        
        for col in numeric_cols:
            if col == target_column:
                continue
            Q1 = patient_data[col].quantile(0.25)
            Q3 = patient_data[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 3 * IQR
            upper_bound = Q3 + 3 * IQR
            
            flagged_as_outlier = ~patient_data[col].between(lower_bound, upper_bound) & patient_data[col].notna()
            outlier_votes += flagged_as_outlier.astype(int)
        
        outlier_removed_data = patient_data[outlier_votes <= vote_threshold]
        removed_count = len(patient_data) - len(outlier_removed_data)
        print(f"Removed {removed_count} outlier records (flagged as extreme in more than {vote_threshold} columns)")
        
        return outlier_removed_data
    
    def engineer_interactions(self, feature_data):
        engineered_data = feature_data.copy()
        
        engineered_data['age_severity_interaction'] = engineered_data['age'] * engineered_data['severity_index']
        engineered_data['respiratory_stress'] = engineered_data['resp'] * engineered_data['pafi']
        engineered_data['cardiac_metabolic_stress'] = engineered_data['hrt'] * engineered_data['glucose']
        
        return engineered_data
    
    def prepare_training_data(self, development_data):
        print("\n--- Training Data Preparation ---")
        
        feature_engineered = self.prepare_features(development_data)
        feature_engineered = self.remove_outliers(feature_engineered, target_column='death')
        feature_engineered = self.engineer_interactions(feature_engineered)
        
        survival_outcome = feature_engineered['death']
        
        cols_to_exclude = ['Id', 'death']
        patient_features = feature_engineered.drop(columns=cols_to_exclude, errors='ignore')
        
        categorical_cols = ['age_group', 'sex', 'dzgroup', 'dzclass', 'race', 
                            'income', 'dnr', 'medical_center', 'admission_month', 
                            'ca', 'diabetes', 'dementia']
        patient_features = pd.get_dummies(patient_features, columns=categorical_cols, drop_first=True)
        
        self.training_columns = patient_features.columns.tolist()
        
        print(f"Features after engineering: {patient_features.shape[1]}")
        print(f"Outcome distribution - Survived: {(survival_outcome == 0).sum()}, Died: {(survival_outcome == 1).sum()}")
        
        return patient_features, survival_outcome
    
    def train_model(self, patient_features, survival_outcome):
        print("\n--- Model Training ---")
        
        train_x, holdout_x, train_y, holdout_y = train_test_split(
            patient_features, survival_outcome, test_size=0.2,
            stratify=survival_outcome, random_state=self.random_state
        )
        
        self.feature_scaler = RobustScaler()
        train_scaled = self.feature_scaler.fit_transform(train_x)
        train_scaled = pd.DataFrame(train_scaled, columns=patient_features.columns)
        
        # Expanded K to accommodate one-hot encoded columns after trying different numbers 40, 50, 60, 70
        self.feature_selector = SelectKBest(f_classif, k=min(70, train_scaled.shape[1]))
        train_selected = self.feature_selector.fit_transform(train_scaled, train_y)
        
        self.selected_feature_names = train_scaled.columns[self.feature_selector.get_support()].tolist()
        train_selected = pd.DataFrame(train_selected, columns=self.selected_feature_names)
        
        print(f"Selected {len(self.selected_feature_names)} features")
        
        holdout_scaled = self.feature_scaler.transform(holdout_x)
        holdout_scaled = pd.DataFrame(holdout_scaled, columns=patient_features.columns)
        holdout_selected = self.feature_selector.transform(holdout_scaled)
        holdout_selected = pd.DataFrame(holdout_selected, columns=self.selected_feature_names)
        
        cv_strategy = StratifiedKFold(n_splits=3, shuffle=True, random_state=self.random_state)
        #the best params that gave me the best output
        log_reg_params = {
            'C': [0.1],
            'solver': ['saga'],
            'class_weight': ['balanced']
        }
        
        forest_params = {
            'n_estimators': [100, 200],
            'max_depth': [10, 15],
            'class_weight': ['balanced']
        }
        
        gradient_params = {
            'n_estimators': [100, 200],
            'max_depth': [5, 7],
            'learning_rate': [0.05, 0.1]
        }
        #max iter 3000 worked best after trying 2000 and 1000
        log_reg_search = GridSearchCV(
            LogisticRegression(random_state=self.random_state, max_iter=3000),
            log_reg_params, cv=cv_strategy, scoring='f1_macro', n_jobs=-1, verbose=0
        )
        log_reg_search.fit(train_selected, train_y)
        best_logistic = log_reg_search.best_estimator_
        logistic_holdout_f1 = f1_score(holdout_y, best_logistic.predict(holdout_selected), average='macro')
        print(f"Logistic Regression - CV F1: {log_reg_search.best_score_:.4f}, Holdout F1: {logistic_holdout_f1:.4f}")
        
        forest_search = GridSearchCV(
            RandomForestClassifier(random_state=self.random_state),
            forest_params, cv=cv_strategy, scoring='f1_macro', n_jobs=-1, verbose=0
        )
        forest_search.fit(train_selected, train_y)
        best_forest = forest_search.best_estimator_
        forest_holdout_f1 = f1_score(holdout_y, best_forest.predict(holdout_selected), average='macro')
        print(f"Random Forest - CV F1: {forest_search.best_score_:.4f}, Holdout F1: {forest_holdout_f1:.4f}")
        
        gradient_search = GridSearchCV(
            GradientBoostingClassifier(random_state=self.random_state),
            gradient_params, cv=cv_strategy, scoring='f1_macro', n_jobs=-1, verbose=0
        )
        gradient_search.fit(train_selected, train_y)
        best_gradient = gradient_search.best_estimator_
        gradient_holdout_f1 = f1_score(holdout_y, best_gradient.predict(holdout_selected), average='macro')
        print(f"Gradient Boosting - CV F1: {gradient_search.best_score_:.4f}, Holdout F1: {gradient_holdout_f1:.4f}")
        
        self.ensemble_model = VotingClassifier(
            estimators=[
                ('logistic', best_logistic),
                ('forest', best_forest),
                ('gradient', best_gradient)
            ],
            voting='soft'
        )
        self.ensemble_model.fit(train_selected, train_y)
        ensemble_holdout_f1 = f1_score(holdout_y, self.ensemble_model.predict(holdout_selected), average='macro')
        print(f"Ensemble - Holdout F1: {ensemble_holdout_f1:.4f}")
        
        self.holdout_features = holdout_selected
        self.holdout_outcome = holdout_y
    
    def optimize_classification_threshold(self, patient_features, survival_outcome):
        print("\n--- Threshold Optimization ---")
        
        survival_probabilities = self.ensemble_model.predict_proba(self.holdout_features)[:, 1]
        
        best_f1 = 0
        best_threshold = 0.5
        
        for threshold in np.arange(0.3, 0.7, 0.01):
            threshold_predictions = (survival_probabilities >= threshold).astype(int)
            threshold_f1 = f1_score(self.holdout_outcome, threshold_predictions, average='macro')
            
            if threshold_f1 > best_f1:
                best_f1 = threshold_f1
                best_threshold = threshold
        
        self.optimal_threshold = best_threshold
        print(f"Optimal threshold: {self.optimal_threshold:.3f} (Holdout F1: {best_f1:.4f})")
    
    def predict_on_evaluation_set(self, evaluation_data):
        print("\n--- Generating Evaluation Predictions ---")
        
        feature_engineered = self.prepare_features(evaluation_data)
        feature_engineered = self.engineer_interactions(feature_engineered)
        
        patient_features = feature_engineered.drop(columns=['Id'], errors='ignore')
        
        categorical_cols = ['age_group', 'sex', 'dzgroup', 'dzclass', 'race', 
                            'income', 'dnr', 'medical_center', 'admission_month', 
                            'ca', 'diabetes', 'dementia']
        patient_features = pd.get_dummies(patient_features, columns=categorical_cols, drop_first=True)
        
        for col in self.training_columns:
            if col not in patient_features.columns:
                patient_features[col] = 0
        
        patient_features = patient_features[self.training_columns]
        
        scaled_features = self.feature_scaler.transform(patient_features)
        scaled_features = pd.DataFrame(scaled_features, columns=patient_features.columns)
        
        selected_features = self.feature_selector.transform(scaled_features)
        selected_features = pd.DataFrame(selected_features, columns=self.selected_feature_names)
        
        survival_probabilities = self.ensemble_model.predict_proba(selected_features)[:, 1]
        final_predictions = (survival_probabilities >= self.optimal_threshold).astype(int)
        
        print(f"Predictions generated: {len(final_predictions)} samples")
        print(f"Predicted deaths: {final_predictions.sum()}, Predicted survivors: {(final_predictions == 0).sum()}")
        
        return final_predictions, evaluation_data['Id'].values
    
    def save_submission(self, predictions, patient_ids, output_path='submission.csv'):
        submission_frame = pd.DataFrame({
            'Id': patient_ids,
            'Predicted': predictions
        })
        
        submission_frame.to_csv(output_path, index=False)
        print(f"\nSubmission saved to {output_path}")
        print(f"File size: {os.path.getsize(output_path) / 1024:.2f} KB")
        
        return submission_frame


def main():
    predictor = PatientSurvivalPredictor(random_state=42)
    
    dev_data, eval_data = predictor.load_datasets(
        dev_path='development.csv',
        eval_path='evaluation.csv'
    )
    
    training_features, training_outcome = predictor.prepare_training_data(dev_data)
    predictor.train_model(training_features, training_outcome)
    predictor.optimize_classification_threshold(training_features, training_outcome)
    
    eval_predictions, eval_patient_ids = predictor.predict_on_evaluation_set(eval_data)
    predictor.save_submission(eval_predictions, eval_patient_ids, output_path='submission.csv')
    print("Everything is complete!")


if __name__ == '__main__':
    main()